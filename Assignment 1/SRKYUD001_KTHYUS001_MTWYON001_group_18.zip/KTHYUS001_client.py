import datetime
import hashlib
import platform
import socket
import sys
import os

from math import ceil, log

# HOST = "196.24.172.241"
# port 1200 works on eduroam!!!!
# PORT = 1200

# GET request header formats
GET_REQUEST = """GET {filename}
DATE: {date}
DEVICE: {device}
PRIVACY: {file_privacy}
KEY: {file_key}

EOF"""

# UPLOAD request header format
UPLOAD_REQUEST = """UPLOAD {filename}
DATE: {date}
DEVICE: {device}
PRIVACY: {file_privacy}
KEY: {file_key}

EOF"""

# LIST request header format
LIST_REQUEST = """LIST
DATE: {date}
DEVICE: {device}
PRIVACY: {file_privacy}
KEY: {file_key}

EOF"""

# Confirmation message
CONFIRMATION_RECEIVED_FILE = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF"""


# Function that sends header messages
def send_header(s, header):
    s.sendall(header.encode())


# Function that sends the data, in this case we are sending a file
def send_data(s, filename):
    with open(filename, "rb") as f:
        send_data = f.read(1024)
        s.send(send_data)
        while (send_data):
            send_data = f.read(1024)
            s.send(send_data)
        s.send(b"EOF")


# Function that receives headers from server
def receive_header(s):
    complete_data = str()
    while True:
        data = s.recv(1024)
        if b"EOF" in data:
            # Decoding data is necessary as messages are encoded to be sent
            complete_data += data.decode()
            break
        complete_data += data.decode()
    msg = msg_is_valid(complete_data)
    if msg == "true":
        return complete_data
    else:
        return msg


# Function that checks that message contains all necessary info and correct format
def msg_is_valid(data):
    sp = data.split("\n")
    if ("GET" in sp[0] or "UPLOAD" in sp[0]) and ("DATE" in sp[1] and "MACHINE" in sp[2] and "EOF" in sp[len(sp) - 1]):
        return "true"
    elif "400 File already exists" in sp[0]:
        return "File Already exists"
    return "Message Invalid"


# Function that receives data, in this case we are receiving files
def receive_data(s, filename):
    complete_data = str()
    data = s.recv(1024).decode()
    # print(data)
    headers = data.split("\n\n")[0]
    header_values = headers.split("\n")
    header_list = list()
    for i in header_values:
        for j in i.split(": "):
            header_list.append(j)
    # print(header_list)
    it = iter(header_list[1:])
    header_dict = {k: next(it) for k in it}

    if "File does not exist" in header_list[0]:
        # File doesn't exist
        print("File does not exist.")

    elif "OK" in header_list[0]:
        with open(filename, "wb") as f:
            while True:
                data = s.recv(1024)
                if b"EOF" in data:
                    if data[-3:] == b"EOF":
                        f.write(data[:-3])
                        print("\nDownload in progress")
                        break
                    # else:
                    # print("There is a problem with the message!!!!!")
                f.write(data)

        checksum = str()
        with open(filename, "rb") as f:
            data = f.read()

            # checksum function that validates that the file received by client is correct and matches the file on the
            # server. Files can be corrupted in transit and this verifies that it is correct.
            checksum = hashlib.sha256(data).hexdigest()

        if checksum == header_dict["CHECKSUM"]:
            # You need to code the server side to handle this part where
            # it will receive the confirmation.
            date = datetime.datetime.now()
            send_header(s, CONFIRMATION_RECEIVED_FILE.format(
                response_code=200,
                response_message="File Received",
                date=date.strftime("%d/%m/%Y"),
                device=platform.platform(), ))
        else:
            print("File corrupted in transit. Please retry your request.")
    elif "File needs a key" in header_list[0]:
        print("Please provide a key.")


# Function that extracts information from the headers. Splits each component from header by new line
def extract_header(data):
    # print(data)
    headers = data.split("\n\n")[0]

    header_values = headers.split("\n")
    return header_values


# Function that allows user to GET (download) files from server. If the file requested is PROTECTED, the user will need
# to input the key they specified when uploading.
def file_download_from_server_test(s, filename, privacy, key):
    date = datetime.datetime.now()
    send_header(s, GET_REQUEST.format(
        filename=filename,
        date=date.strftime("%H:%M:%S %z %d-%m-%Y "),
        device=platform.platform(),
        file_privacy=privacy,
        file_key=key))
    # Will use the following code to get the acknowledgement of the final
    # message and then close the connection.
    receive_data(s, filename)
    send_header(s, CONFIRMATION_RECEIVED_FILE.format(
        response_code=200,
        response_message="File Received",
        date=date.strftime("%d/%m/%Y"),
        device=platform.platform(), ))
    print("\nDONE\n")

# Function that allows user to UPLOAD files to server. Users must specify OPEN/PROTECTED and if PROTECTED add the key
# they wish to use to have access to the file.
def file_upload_to_server_test(s, filename, privacy, key):
    # The below code is for uploading to the server.
    date = datetime.datetime.now()
    send_header(s, UPLOAD_REQUEST.format(
        filename=filename,
        date=date.strftime("%H:%M:%S %z %d-%m-%Y "),
        device=platform.platform(),
        file_privacy=privacy,
        file_key=key))
    data = s.recv(1024).decode()
    header_values = extract_header(data)
    # print(header_values)
    if "200" in header_values[0]:
        send_data(s, filename)
        data = s.recv(1024).decode()
        header_values_response = extract_header(data)
        # print(header_values_response)
        if "200" in header_values_response[0]:
            print("File has been received")
        else:
            print("File has not been received. Please try again")
    else:
        print(header_values[0])

# Function that allows users to LIST files available on the server. If files are protected the user will have to input
# the PROTECTED keyword as well as the key for the files in order to be able to view them. No key is required to view
# OPEN files
def list_files(s, privacy, key):
    date = datetime.datetime.now()
    send_header(s, LIST_REQUEST.format(
        date=date.strftime("%H:%M:%S %z %d-%m-%Y "),
        device=platform.platform(),
        file_privacy=privacy,
        file_key=key))
    data = s.recv(1024).decode()
    header_values = extract_header(data)
    print("File Name            Privacy     Size    Last Modified\n"
          "------------------------------------------------------------")
    print("\n"+data.split("\n\n")[1])


# main client function that runs when program is run
def client():
    format_msg = "Unrecognisable request. Please send message in the following format: \n " \
                 "[host] [port] [GET/UPLOAD/LIST] [OPEN/PROTECTED] [key *if protected*] [file name]"

    # users can enter [HELP] and will be met with the following message:
    if sys.argv[1] == "HELP":
        print("\n------ Welcome to FileHub! ------\n"
              "Your solution to effortless file transfers. \n"
              "\nTo ensure you have a pleasant experience, please submit your request in the following format:\n"
              "\n[host] [port] [GET/UPLOAD/LIST] [OPEN/PROTECTED] [key *if protected*] [file name *for GET or "
              "UPLOAD request*]\n")
        sys.exit()

    try:
        msg_len = len(sys.argv)

        # CLI parsing user input from command line
        host = str(sys.argv[1])
        port = int(sys.argv[2])
        request = str(sys.argv[3])
        privacy = str(sys.argv[4])
        key = "NONE"
        filename = None

        if privacy == "PROTECTED":
            key = sys.argv[5]

        if request == "GET" or request == "UPLOAD":
            filename = sys.argv[-1]

    except:
        print(format_msg)

    # Connecting to socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect((host, port))
            print("Connection Successful\n")

            if msg_len - 1 >= 4:
                if request == "GET":
                    file_download_from_server_test(s, filename, privacy, key)
                elif request == "UPLOAD":
                    if os.path.exists(filename) == True:
                        file_upload_to_server_test(s, filename, privacy, key)
                    else:
                        print("Incorrect filename or file does not exist\n")
                elif request == "LIST":
                    list_files(s, privacy, key)
                else:
                    print(format_msg)
                    s.shutdown(2)
                    s.close()
            else:
                print(format_msg)
                s.shutdown(2)
                s.close()

            # if msg_len - 1 >= 4:
            #     if request == "GET":
            #         file_download_from_server_test(s, filename, privacy, key)
            #     elif request == "UPLOAD":
            #         file_upload_to_server_test(s, filename, privacy, key)
            #     elif request == "LIST":
            #             list_files(s, privacy, key)
            #     else:
            #         print(format_msg)
            #         s.shutdown(2)
            #         s.close()

        except:
            print("Connection Unsuccessful")
            s.shutdown(2)
            s.close()


if __name__ == "__main__":
    client()

    # To test the different functionality you have to uncomment each function
    # call but only 1 function call can be uncommented at a time since
    # running all the functions won't work well.
    # file_download_from_server_test(s, FILENAME)
    # file_upload_to_server_test(s, FILENAME)
    # list_files(s, "NONE")
