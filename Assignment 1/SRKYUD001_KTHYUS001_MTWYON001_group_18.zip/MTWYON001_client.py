import argparse
import datetime
import hashlib
import platform
import socket
import os

from math import ceil, log



# PORT = 65434
# PORT = 65432
# PORT = 65434

# The below are the request messages and response message
GET_REQUEST = """GET {filename}
DATE: {date}
DEVICE: {device}
PRIVACY: {file_privacy}
KEY: {file_key}

EOF"""

UPLOAD_REQUEST = """UPLOAD {filename}
DATE: {date}
DEVICE: {device}
PRIVACY: {file_privacy}
KEY: {file_key}

EOF"""

LIST_REQUEST = """LIST
DATE: {date}
DEVICE: {device}
PRIVACY: {file_privacy}
KEY: {file_key}

EOF"""

CONFIRMATION_RECEIVED_FILE = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF"""

# Used to send the header
def send_header(s, header):
    s.sendall(header.encode())
    # s.send(b"EOF")

# Used to send the data
def send_data(s, filename):
    with open(filename, "rb") as f:
        send_data = f.read(1024)
        s.send(send_data)
        while (send_data):
            send_data = f.read(1024)
            s.send(send_data)
        s.send(b"EOF")

# Used to recieve the header
def recieve_header(s):
    complete_data = str()
    while True:
        data = s.recv(1024)
        if b"EOF" in data:
            complete_data += data.decode()
            break
        complete_data += data.decode()
    msg = msg_is_valid(complete_data)
    if msg == "true":
        return complete_data
    else:
        return msg

# Used to check if the message is valid
def msg_is_valid(data):

    sp = data.split("\n")
    #print(sp)
    if ("GET" in sp[0] or "UPLOAD" in sp[0] ) and ("DATE" in sp[1] and "MACHINE" in sp[2] and "EOF" in sp[len(sp)-1]):
        return "true"
    elif "401 File already exists" in sp[0]:
        return "File Already exists"
    return "Message Invalid"

# Used to recieve the data
def recieve_data(s, filename):
    complete_data = str()

    data = s.recv(1024).decode()
    headers = data.split("\n\n")[0]

    header_values = headers.split("\n")
    header_list = list()
    for i in header_values:
        for j in i.split(": "):
            header_list.append(j)
    it = iter(header_list[1:])
    header_dict = {k: next(it) for k in it}

    if "404" in header_list[0]:
        print("File doesn't exist!")

    elif "OK" in header_list[0]:
        with open(filename, "wb") as f:
            while True:
                data = s.recv(1024)
                if b"EOF" in data:
                    if data[-3:] == b"EOF":
                        f.write(data[:-3])
                        break
                f.write(data)
        checksum = str()
        with open(filename, "rb") as f:
            data = f.read()
            checksum = hashlib.sha256(data).hexdigest()

        if checksum == header_dict["CHECKSUM"]:
            # You need to code the server side to handle this part where it
            # it will recieve the confirmation.
            date = datetime.datetime.now()
            send_header(s, CONFIRMATION_RECEIVED_FILE.format(
                    response_code = 200,
                    response_message = "File Received",
                    date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                    device = platform.platform(),
                ))
            print("File successfully downloaded.")
        else:
            print("Please retry downloading the file")

    elif "402" in header_list[0]:
        print("Incorrect key")
    elif "403" in header_list[0]:
        print("Please provide a key.")
    elif "400" in header_values[0]:
        print("Bad request. Please try again")

# Used to extract the header information
def extract_header(data):
    headers = data.split("\n\n")[0]

    header_values = headers.split("\n")
    return header_values

# This is the download functionality
def file_download_from_server_test(s, filename, privacy, key):
    ## The below code is for downloading the file from the server.
    date = datetime.datetime.now()
    send_header(s, GET_REQUEST.format(
                        filename = filename,
                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                        device = platform.platform(),
                        file_privacy = privacy,
                        file_key = key
                        )
                )

    # Will use the following code to get the acknowledgement of the final
    # message and then close the connection.

    # print(recieve_header(s))
    recieve_data(s, filename)
    send_header(s, CONFIRMATION_RECEIVED_FILE.format(
                            response_code = 200,
                            response_message = "File Received",
                            date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                            device = platform.platform(),
                        )
                )

# This is the uploading functionality
def file_upload_to_server_test(s, filename, privacy, key):
    ### The below code is for uploading to the server.
    date = datetime.datetime.now()
    send_header(s, UPLOAD_REQUEST.format(
                        filename = filename,
                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                        device = platform.platform(),
                        file_privacy = privacy,
                        file_key = key
                        )
                )
    data = s.recv(1024).decode()
    header_values = extract_header(data)

    if "200" in header_values[0]:
        send_data(s, filename)
    elif "401" in header_values[0]:
        print("File already exists. Please upload the file with a different filename.")
    elif "405" in header_values[0]:
        print("Key cannot be NONE")
    elif "400" in header_values[0]:
        print("Bad request. Please try again")
    else:
        print(header_values[0])

# This is the listing functionality
def list_files(s, privacy, key):
    date = datetime.datetime.now()
    send_header(s, LIST_REQUEST.format(
                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                        device = platform.platform(),
                        file_privacy = privacy,
                        file_key = key
                        )
                )
    data = s.recv(1024).decode()
    header_values = extract_header(data)
    if "400" in header_values[0]:
        print("Bad request please try again.")
    elif "200" in header_values[0]:
        print("{filename:20s} {privacy:9s} {size:7s} {last_modified:20s}".format(
            filename = "filename",
            privacy = "privacy",
            size = "size",
            last_modified = "last modified"))
        print("-------------------------------------------------------")
        print(data.split("\n\n")[1])

# This is the main method for running the client
def main():
    parser = argparse.ArgumentParser(description = "Client for filehub network application")
    group = parser.add_mutually_exclusive_group(required=True)
    
    # This specifies the server ip address
    parser.add_argument("-s", "--server",
                        type = str,
                        nargs = 1,
                        required = True,
                        help = "Specify the server address")
    
    # This specifies the port to connect to
    parser.add_argument("-p", "--port",
                        type = str,
                        nargs = 1,
                        required = True,
                        help = "Specify the server port")
    
    group.add_argument("-d", "--download",
                        type = str,
                        nargs = 1,
                        help = "Specify the file you would like to download")
    
    group.add_argument("-u", "--upload",
                        type = str,
                        nargs = 1,
                        help = "Specify the file you would like to upload")
    
    group.add_argument("-l", "--list",
                        action = "store_const",
                        help = "List the files on the server")
    
    parser.add_argument("-k", "--key",
                        type = str,
                        nargs = 1,
                        help = "Specify the key")
    args = parser.parse_args()
    
    HOST = args.server[0]
    PORT = int(args.port[0])
    
    if args.download is not None:
        # We actually do the download
        if args.key is None:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((HOST, PORT))
                file_download_from_server_test(s, args.download[0], "OPEN", "NONE")
        elif len(args.key) == 1:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((HOST, PORT))
                file_download_from_server_test(s, args.download[0], "PROTECTED", args.key[0])
    elif args.upload is not None:
        # We actually do the upload
        if args.key is None:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((HOST, PORT))
                file_upload_to_server_test(s, args.upload[0], "OPEN", "NONE")
        elif len(args.key) == 1:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((HOST, PORT))
                file_upload_to_server_test(s, args.upload[0], "PROTECTED", args.key[0])
    else:
        # We actually do the listing
        if args.key is None:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((HOST, PORT))
            
                list_files(s, "OPEN", "NONE")
        elif len(args.key) == 1:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((HOST, PORT))
                list_files(s, "OPEN", args.key[0])

if __name__ == "__main__":
    main()
