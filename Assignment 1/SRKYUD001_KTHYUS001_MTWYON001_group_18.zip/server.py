import datetime
import hashlib
import platform
import socket
import os
import stat
import time
import sqlite3

from os.path import exists, getsize, getmtime, getsize


PORT = 1200
HOST = "0.0.0.0"

# Below are the response messages that will be sent
RESPONSE_MESSAGE = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}
CONTENT-LENGTH: {file_size}
CHECKSUM: {checksum}

EOF
"""

RESPONSE_FILE_EXISTS = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF
"""

RESPONSE_FILE_DOES_NOT_EXIST = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF
"""

RESPONSE_MISSING_KEY = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF
"""

RESPONSE_KEY_CANNOT_BE_NONE = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF
"""

CONFIRMATION_RECEIVED_FILE = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF
"""

RESPONSE_OK_TO_SEND = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF
"""

RESPONSE_LIST = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

{file_list}

EOF
"""

RESPONSE_BAD_REQUEST = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF
"""

DATABASE = "filehub.db"

# Converts bytes to human readable sizes
def human_size(bytes, units=[' bytes', 'KB', 'MB', 'GB']):
    return str(bytes) + units[0] if bytes < 1000 else human_size(bytes>>10, units[1:])

# Connects to the database
def connect_to_database(database):
    connection = sqlite3.connect(database)
    return connection

# Creates the table to store information about the files
def create_table(connection):
    cursor = connection.cursor()
    cursor.execute("CREATE TABLE file_record (filename TEXT, key TEXT, privacy TEXT, file_size TEXT, last_modified TEXT)")

# Used to insert the entries for the respective files.
def insert_filenames(connection, filename, key, privacy, file_size, last_modified):
    cursor = connection.cursor()
    cursor.execute("INSERT INTO file_record VALUES ( ? , ? , ? , ? , ? )", (filename, key, privacy, file_size, last_modified,),)
    connection.commit()

# Used to check if the privacy of a file is open
def is_file_open(connection, filename):
    # So this helps us check if the file actually exists and if it's open.
    cursor = connection.cursor()
    row = cursor.execute("SELECT * FROM file_record WHERE filename = ? AND key = 'NONE'", (filename,),).fetchone()

    return row is not None

# Used to check if the file exists in the database
def does_file_exist(connection, filename):
    # So this helps us check if the file exists in the database.
    cursor = connection.cursor()
    row = cursor.execute("SELECT * FROM file_record WHERE filename = ?", (filename,),).fetchone()

    return row is not None

# Used to retrieve the filenames from the database
def retriving_filenames(connection, filename, key):
    cursor = connection.cursor()
    if key == "NONE":
        # Has to be fetchall
        rows_all = cursor.execute("SELECT * FROM file_record WHERE filename = ?", (filename,),).fetchone()
    elif key != "NONE":
        # Has to be fetchone
        rows = cursor.execute("SELECT * FROM file_record WHERE filename = ? AND key = ?",
                   (filename, key,),).fetchone()
    print(rows)
    return rows

# Used to determine if it is correct key for the file in the database
def is_correct_key_for_file(connection, key, filename):
    cursor = connection.cursor()

    row = cursor.execute("SELECT * FROM file_record WHERE filename = ? AND key = ?", (filename, key,),).fetchone()

    return row is not None

# Used to list the files that are recorded in the database
def list_files(connection, key):
    cursor = connection.cursor()

    if key == "NONE":
        rows = cursor.execute("SELECT * FROM file_record WHERE key = 'NONE'").fetchall()
    elif key != "NONE":
        rows = cursor.execute("SELECT * FROM file_record WHERE key = ? OR key = 'NONE'", (key,),).fetchall()

    return rows

# Used to send just the header
def send_header(conn, header):
    conn.sendall(header.encode())

# Used to send the data
def send_data(conn, filename):
    with open(filename, "rb") as f:
        send_data = f.read()
        conn.send(send_data)
        conn.send(b"EOF")

# Used to receive the header
def recieve_header(conn):
    complete_data = str()
    while True:
        data = conn.recv(1024)
        #print(data)
        if b"EOF" in data:
            complete_data += data.decode()
            break
        complete_data += data.decode()
    if request_msg_is_valid(complete_data):
        print("Request:", complete_data)
        return complete_data
    elif response_msg_is_valid(complete_data):
        print("Response:", complete_data)
        return complete_data
    print("Outside:", complete_data)
    return "Message Invalid"
    

#determines whether the message received is valid basesd on its format
def request_msg_is_valid(data):
    sp = data.split("\n")
    if ("GET" in sp[0] or "UPLOAD" in sp[0] or "LIST" in sp[0]) and ("DATE" in sp[1] and "DEVICE" in sp[2] and "EOF" in sp[len(sp)-1]):
        return True
    return False
        
# Determines if response message is valid
def response_msg_is_valid(data):
    sp = data.split("\n")
    if ("200" in sp[0] or "400" in sp[0] ) and ("DATE" in sp[1] and "DEVICE" in sp[2] and "EOF" in sp[len(sp)-1]):
        return True
    return False

# Used to recieve the data
def recieve_data(conn, filename):
    with open(filename, "wb") as f:
        while True:
            data = conn.recv(1024)
            if b"EOF" in data:
                if data[-3:] == b"EOF":
                    f.write(data[:-3])
                    print("DONE")
                    break
            f.write(data)

# Used to list the available files in the server not from the database
def list_available_files(conn):
    location = "server/"
    files_available = []

    for r,d,f in os.walk(location):
        for item in f:

            file_stat = os.stat(location + item)
            modification_time = time.ctime(file_stat[stat.ST_MTIME])
            files_available.append(f'{os.path.join(item):15} {str(round(os.path.getsize(os.path.join(location, item)) / 10)):10}KB{"":10} {modification_time:10}')

    conn.send(b"********* Available Files **********\n\nFile Name:      File Size:             Last Modified:\n")
    for item in files_available:
        conn.send(item.encode())
        conn.send(b"\n")

# Used to run the server functionality
def server():
    try:
        create_table(connect_to_database(DATABASE))
    except:
        print("Table already exists")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        while True:
            conn, addr = s.accept()
            with conn:
                print(f"Connected by {addr}")
                msg = recieve_header(conn)
                if msg != "Message Invalid":
                    headers = msg.split("\n\n")[0]

                    header_values = headers.split("\n")
                    header_list = list()
                    for i in header_values:
                        for j in i.split(": "):
                            header_list.append(j)
                    print(header_list)
                    it = iter(header_list[1:])
                    header_dict = {k: next(it) for k in it}

                    if "GET" in header_list[0]:

                        filename = header_list[0].split(" ")[1]

                        if does_file_exist(connect_to_database(DATABASE), filename):
                            # File exists
                            if header_dict["PRIVACY"] == "OPEN":
                                # We shall send the open files as usual.
                                if is_file_open(connect_to_database("filehub.db"), filename):
                                    print("File is open")
                                    print("Sending:", filename)
                                    date = datetime.datetime.now()

                                    with open(filename, "rb") as f:
                                        data = f.read()

                                    date = datetime.datetime.now()
                                    send_header(conn, RESPONSE_MESSAGE.format(
                                            response_code = 200,
                                            response_message = "OK",
                                            date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                            device = platform.platform(),
                                            file_size = getsize(filename),
                                            checksum = hashlib.sha256(data).hexdigest()
                                        ))
                                    send_data(conn, filename)
                                    response_header = recieve_header(conn).split("\n\n")[0]
                                    response_header_items = response_header.split("\n")
                                    print(response_header_items)

                                    if "200" in response_header_items[0]:
                                        print("File has been completely sent!!!!!")
                                    else:
                                        print("File has not been entirely sent")
                                else:
                                    print("File needs a key")
                                    date = datetime.datetime.now()
                                    send_header(conn, RESPONSE_MISSING_KEY.format(
                                            response_code = 403,
                                            response_message = "Key required",
                                            date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                            device = platform.platform()
                                        ))

                            elif header_dict["PRIVACY"] == "PROTECTED":

                                rows = retriving_filenames(connect_to_database("filehub.db"), filename, header_dict["KEY"])

                                if rows is None:
                                    # Return a response saying the key was incorrect
                                    date = datetime.datetime.now()
                                    send_header(conn, RESPONSE_MISSING_KEY.format(
                                            response_code = 402,
                                            response_message = "Incorrect key",
                                            date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                            device = platform.platform()
                                        ))

                                elif rows is not None:
                                    # Send the file to the client
                                    with open(filename, "rb") as f:
                                        data = f.read()
                                    print("Sending:", filename)
                                    date = datetime.datetime.now()
                                    send_header(conn, RESPONSE_MESSAGE.format(
                                            response_code = 200,
                                            response_message = "OK",
                                            date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                            device = platform.platform(),
                                            file_size = getsize(filename),
                                            checksum = hashlib.sha256(data).hexdigest()
                                        ))
                                    send_data(conn, filename)
                                    response_header = recieve_header(conn).split("\n\n")[0]
                                    response_header_items = response_header.split("\n")

                                    if "200" in response_header_items[0]:
                                        print("File has been completely sent!!!!!")
                                    else:
                                        print("File has not been entirely sent")

                        else:
                            # File doesn't exist
                            date = datetime.datetime.now()
                            send_header(conn, RESPONSE_FILE_DOES_NOT_EXIST.format(
                                    response_code = 404,
                                    response_message = "File does not exist",
                                    date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                    device = platform.platform()
                                ))

                    elif "UPLOAD" in header_list[0]:

                        filename = header_list[0].split(" ")[1]

                        if does_file_exist(connect_to_database(DATABASE), filename):
                            # File exists
                            date = datetime.datetime.now()
                            send_header(conn, RESPONSE_FILE_EXISTS.format(
                                    response_code = 401,
                                    response_message = "File already exists",
                                    date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                    device = platform.platform(),
                                ))
                        else:
                            # File doesn't exist
                            print("File doesn't exist")
                            if header_dict["KEY"] != "NONE" and header_dict["PRIVACY"] == "PROTECTED":
                                # The file is protected since and the key is not NONE
                                print("The key is not NONE and the file is PROTECTED")
                                print("Recieving:", filename)
                                date = datetime.datetime.now()
                                send_header(conn, RESPONSE_OK_TO_SEND.format(
                                        response_code = 200,
                                        response_message = "OK",
                                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                        device = platform.platform(),
                                    ))
                                recieve_data(conn, filename)
                                m_time = getmtime(filename)
                                modified_datetime = datetime.datetime.fromtimestamp(m_time)
                                file_size = getsize(filename)
                                insert_filenames(connect_to_database(DATABASE),
                                                    filename,
                                                    header_dict["KEY"],
                                                    header_dict["PRIVACY"],
                                                    human_size(file_size),
                                                    modified_datetime.strftime("%H:%M:%S %z %d-%m-%Y")
                                        )
                                send_header(conn, CONFIRMATION_RECEIVED_FILE.format(
                                        response_code = 200,
                                        response_message = "OK",
                                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                        device = platform.platform(),
                                    ))
                            elif header_dict["KEY"] == "NONE" and header_dict["PRIVACY"] == "OPEN":
                                # This file is available to everyone
                                print("This is an open file")
                                print("Recieving:", filename)
                                date = datetime.datetime.now()
                                send_header(conn, RESPONSE_OK_TO_SEND.format(
                                        response_code = 200,
                                        response_message = "OK",
                                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                        device = platform.platform(),
                                    ))
                                recieve_data(conn, filename)
                                m_time = getmtime(filename)
                                modified_datetime = datetime.datetime.fromtimestamp(m_time)
                                file_size = getsize(filename)
                                insert_filenames(connect_to_database(DATABASE),
                                                    filename,
                                                    header_dict["KEY"],
                                                    header_dict["PRIVACY"],
                                                    human_size(file_size),
                                                    modified_datetime.strftime("%H:%M:%S %z %d-%m-%Y")
                                        )
                                date = datetime.datetime.now()
                                send_header(conn, CONFIRMATION_RECEIVED_FILE.format(
                                        response_code = 200,
                                        response_message = "OK",
                                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                        device = platform.platform(),
                                    ))
                            elif header_dict["KEY"] == "NONE" and header_dict["PRIVACY"] == "PROTECTED":
                                print("The key cannot be NONE")
                                date = datetime.datetime.now()
                                send_header(conn, RESPONSE_KEY_CANNOT_BE_NONE.format(
                                        response_code = 405,
                                        response_message = "Key cannot be NONE",
                                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                        device = platform.platform(),
                                    ))
                            else:
                                # Since the key is not NONE we can create an entry.
                                print("There is an issue")

                    elif "LIST" in header_list[0]:
                        file_list = list_files(connect_to_database(DATABASE), header_dict["KEY"])
                        file_list_str = str()
                        for i in file_list:
                            file_list_str += "{filename:20s} {privacy:9s} {size:7s} {last_modified:20s}".format(filename = i[0],
                                                                                                                privacy = i[2],
                                                                                                                size = i[3],
                                                                                                                last_modified = i[4]) + "\n"

                        date = datetime.datetime.now()
                        send_header(conn, RESPONSE_LIST.format(
                                response_code = 200,
                                response_message = "OK",
                                date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                                device = platform.platform(),
                                file_list = file_list_str
                            ))
                else:
                    print("Message is incorrect")
                    print(msg)
                    date = datetime.datetime.now()
                    send_header(conn, RESPONSE_BAD_REQUEST.format(
                            response_code = 400,
                            response_message = "Bad request",
                            date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                            device = platform.platform(),
                        ))

if __name__ == "__main__":
    server()
