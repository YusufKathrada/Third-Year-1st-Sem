import datetime
import platform
import socket
import os
import sys
import hashlib


# PORT = 65432
# PORT = 65434

GET_REQUEST = """GET {filename}
DATE: {date}
DEVICE: {device}
PRIVACY: {file_privacy}
KEY: {file_key}

EOF"""

UPLOAD_REQUEST = """UPLOAD {filename}
DATE: {date}
DEVICE: {device}
PRIVACY: {file_privacy}
KEY: {file_key}

EOF"""

LIST_REQUEST = """LIST
DATE: {date}
DEVICE: {device}
PRIVACY: {file_privacy}
KEY: {file_key}

EOF"""

CONFIRMATION_RECEIVED_FILE = """{response_code} {response_message}
DATE: {date}
DEVICE: {device}

EOF"""


def send_header(s, header):
    s.sendall(header.encode())
    # s.send(b"EOF")

def send_data(s, filename):
    
    with open(filename, "rb") as f:
        send_data = f.read(1024)
        s.send(send_data)
        while (send_data):
            send_data = f.read(1024)
            s.send(send_data)
        s.send(b"EOF")

def recieve_header(s):
    complete_data = str()
    while True:
        data = s.recv(1024)
        if b"EOF" in data:
            complete_data += data.decode()
            break
        complete_data += data.decode()
    msg = msg_is_valid(complete_data)
    if msg == "true":
        return complete_data
    else:
        return msg


### checks the if the message is valid based on its format
def msg_is_valid(data):

    sp = data.split("\n")
    #print(sp)
    if ("GET" in sp[0] or "UPLOAD" in sp[0] ) and ("DATE" in sp[1] and "MACHINE" in sp[2] and "EOF" in sp[len(sp)-1]):
        return "true"
    elif "400 File already exists" in sp[0]:
        return "File Already exists"
    return "Message Invalid"

def recieve_data(s, filename):
    complete_data = str()


    data = s.recv(1024).decode()
    headers = data.split("\n\n")[0]
    # complete_data += data.split("\n\n")[1]
    # print(complete_data)

    header_values = headers.split("\n")
    header_list = list()
    for i in header_values:
        for j in i.split(": "):
            header_list.append(j)
    
    it = iter(header_list[1:])
    header_dict = {k: next(it) for k in it}

    if "File does not exist" in header_list[0]:
        # File doesn't exist
        print("File doesn't exist!!!!!")

    elif "OK" in header_list[0]:
        with open(filename, "wb") as f:
            while True:
                #print(data)
                print("Downloading...")

                data = s.recv(1024)
                if b"EOF" in data:
                    if data[-3:] == b"EOF":
                        f.write(data[:-3])
                        print("DONE")
                        break
                f.write(data)
        # You need to code the server side to handle this part where it
        # it will recieve the confirmation.
        checksum =str()
        with open(filename, "rb") as f:
            data = f.read()
            checksum = hashlib.sha256(data).hexdigest()
    
        if checksum == header_dict["CHECKSUM"]:
            print("Checksum Matches")
            date = datetime.datetime.now()
            send_header(s, CONFIRMATION_RECEIVED_FILE.format(
                    response_code = 200,
                    response_message = "File Received",
                    date = date.strftime("%d/%m/%Y"),
                    device = platform.platform(),
                ))
    elif "File needs a key" in header_list[0]:
        print("Please provide a key.")


### returns header values
def extract_header(data):
    #print(data)
    headers = data.split("\n\n")[0]

    header_values = headers.split("\n")
    return header_values


### download from server
def file_download_from_server_test(s, filename, key):
    if key != "NONE":
        privacy = "PROTECTED"
    else:
        privacy = "OPEN"
    date = datetime.datetime.now()
    send_header(s, GET_REQUEST.format(
                        filename = filename,
                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                        device = platform.platform(),
                        file_privacy = privacy,
                        file_key = key
                        )
                    
                )

    recieve_data(s, filename)
    send_header(s, CONFIRMATION_RECEIVED_FILE.format(
                            response_code = 200,
                            response_message = "File Received",
                            date = date.strftime("%d/%m/%Y"),
                            device = platform.platform(),
                        )
                )



### upload to server
def file_upload_to_server_test(s, filename, privacy ,key):

    date = datetime.datetime.now()
    send_header(s, UPLOAD_REQUEST.format(
                        filename = filename,
                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                        device = platform.platform(),
                        file_privacy = privacy,
                        file_key = key
                        )
                )

    data = s.recv(1024).decode()
    header_values = extract_header(data)
    # message = recieve_header(s)
    #print(header_values)
    if "200" in header_values[0]:
        send_data(s, filename)

        data = s.recv(1024).decode()
        header_values_response = extract_header(data)
        #print(header_values_response)
        if "200" in header_values_response[0]:
            print("File has been uploaded")
        elif len(header_values_response) < 1:
            print()
        else:
            print("File has not been received, please resend the request")

    else:
        print(header_values[0])


### lists file in server
def list_files(s, privacy, key):
    date = datetime.datetime.now()
    send_header(s, LIST_REQUEST.format(
                        date = date.strftime("%H:%M:%S %z %d-%m-%Y "),
                        device = platform.platform(),
                        file_privacy = privacy,
                        file_key = key
                        )
                )

    
    data = s.recv(1024).decode()
    header_values = extract_header(data)

    if "200" in header_values[0]:
        print("{f:20s} {p:9s} {s:7s} {lm:20s}".format(
        f = "File Name",
        p = "Privacy",
        s = "Size",
        lm = "Last Modified"))
    print(data.split("\n\n")[1])


if __name__ == "__main__":
    fmt = "Please send message in the following format\n[server-ip] [port] [command] [file_name] <options>"
    print("[server-ip] [port] [command] [file_name] <options>\n")


    ### first 3 values are essential (will always be required)

    try:
        privacy = "OPEN"
        key = "NONE"
        host = str(sys.argv[1])
        port = int(sys.argv[2])
        command = sys.argv[3]
        if command.upper() == "LIST":
            if sys.argv[4] == "--help":
                print("Please enter a message in the following format\nLIST [privacy] <key>")
            else:
                privacy = sys.argv[4]
                if len(sys.argv) > 5: ### if list includes a key
                    key = sys.argv[5]
            

        else:
            if sys.argv[4] == "--help":
                if sys.argv[3] == "GET":
                    print("Please enter a message in the following format\nGET [file_name] <privacy> <key>")
                else:
                    print("Please enter a message in the following format\nUPLOAD [file_name] [privacy] [key]")
            else:
                file_name = sys.argv[4]    ### file name required if command is not LIST
                if len(sys.argv) > 5:
                    privacy = sys.argv[5]
                    if len(sys.argv) > 6: ### if file needs a key
                        key = sys.argv[6]
    except:
        print(fmt)

    if sys.argv[4]!= "--help":
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((host, port))
            print("Connection Successful\n")
            if(len(sys.argv)-1 >= 4):
                if command == "GET":
                    file_download_from_server_test(s, file_name, key)
                elif command == "UPLOAD":
                    file_upload_to_server_test(s, file_name, privacy.upper(), key)
                else:
                    list_files(s,privacy,  key)


